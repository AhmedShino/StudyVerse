import { defineConfig } from "vite";

export default defineConfig({
  root: "www",
  server: { host: "0.0.0.0", port: 5173, strictPort: true },
  preview: { host: "0.0.0.0", port: 4173, strictPort: true },
  build: { outDir: "../dist", emptyOutDir: true }
});
